# andeanfx — point-in-time data pipeline for USD/CLP, USD/COP, USD/PEN

Step 2 of the Andean FX roadmap. It downloads central-bank and market data, stores every
vintage with the time it became usable, and builds a daily as-of panel and starter
features with no look-ahead.

## Setup

```bash
python -m venv .venv && source .venv/bin/activate
pip install -e .            # pandas, pyarrow, requests, pyyaml
pip install pytest && pytest -q   # 12 offline tests, no network needed
```

Credentials (environment variables):

| Source | Needed | Variable |
|---|---|---|
| Banco Central de Chile (SIETE API) | free account from the BCCh statistics site | `BCCH_USER`, `BCCH_PASS` |
| BCRP (Peru) | none | — |
| datos.gov.co (Colombia TRM) | optional app token for higher rate limits | `SOCRATA_APP_TOKEN` |
| FRED | none (public CSV endpoint) | — |

## Daily use

```bash
python -m andeanfx check      # series whose code or release time you must verify first
python -m andeanfx fetch      # download everything enabled, from settings.start to today
python -m andeanfx panel      # -> data/out/panel.parquet  (one row per decision snapshot)
python -m andeanfx features   # -> data/out/features.parquet (one row per date x currency)
python -m andeanfx status     # rows, date range, revisions, % backfilled per series
python -m andeanfx daily      # fetch + panel + features: schedule this every weekday
```

## How point-in-time works

- **Two timestamps per value.** `obs_date` is what the value describes. `available_at` (UTC)
  is when you could first have used it.
- **Release rules.** These APIs return values by reference date only, so each series in
  `config/series.yaml` has a rule mapping `obs_date` to `available_at`: same day at a local
  time, N business days later, weekly, monthly with a lag, or at the snapshot for vendor
  exports. The rules are conservative on purpose. Colombia's TRM is the one case with a
  negative lag, because it is published the evening before it takes effect.
- **Vintages.** Nothing is overwritten. A changed value for a known date is stored as a
  revision, available from the time the pipeline saw it. `vintage: first` in settings
  ignores revisions altogether.
- **Backfilled flag.** History loaded long after release is marked `backfilled`. Its timing
  comes from the rule, not from observation. Once you run `daily` every weekday, new data
  is observed live, and you can compare the rules with actual fetch times to tighten them.
- **Panel.** For each business day it takes the snapshot time (default 12:30 New York) and
  looks up the newest observation available by then. It adds a `<series>__age_d` column
  and blanks values older than `max_age_days`. An assertion stops the build if any value
  postdates its snapshot.
- **Leakage tests.** `tests/` checks that features up to date T are identical whether
  later data exists or is perturbed. Rerun the tests whenever you add a feature.

## Before you trust a backtest: what to fill in

1. **Verify the flagged series** (`python -m andeanfx check`). Series codes and release
   times marked `verify` are my best estimates:
   - `F073.TCO.PRE.Z.D` for dólar observado
   - `PD04640PD` for the PEN interbank rate
   - `32sa-8pi3` for the TRM
   - FRED lags
2. **BCRP intervention codes.** Find the daily FX-operations series (spot purchases and
   sales, FX swaps, CDR-type instruments) in BCRPData's series search. Paste the codes into
   `PEN_BCRP_SPOT_NET` and `PEN_BCRP_FX_SWAPS_NET`, set `enabled: true`, and check the sign
   convention: the features expect sales to be negative.
3. **File-based series.** Drop exports into `data/raw/...` matching each `code` glob, set
   `date_col` and `value_col` (and `sheet`/`skiprows` for Excel), then set `enabled: true`:
   - BanRep offshore forward positions and AFP positions
   - BCCh AFP forwards
   - BCRP AFP data
4. **Vendor data.** Export onshore spot, 1M NDF outrights and daily copper at your snapshot
   time as CSV (`date,px`). Carry features switch on automatically once spot, NDF and SOFR
   are all present.
5. **Snapshot time.** Set it in `config/settings.yaml` to when you will actually trade.

## Layout

```
config/settings.yaml    dates, paths, snapshot time, vintage mode
config/series.yaml      series catalogue: source, code, release rule, verify/enabled flags
andeanfx/sources/       bcch.py, bcrp.py, socrata.py (TRM), fred.py, files.py (vendor & Excel)
andeanfx/timeutil.py    release rules -> available_at
andeanfx/store.py       PIT store (Parquet per series, all vintages), as_of(), knowledge timeline
andeanfx/panel.py       daily as-of panel with staleness columns
andeanfx/features.py    starter P1 features (momentum, RV, commodity residual, carry, flows, BCRP intervention)
andeanfx/cli.py         commands above
tests/                  offline tests with mocked HTTP
```

## Next step

Build the targets (vol-scaled forward returns, triple-barrier labels, BCRP intervention
probability) and the purged walk-forward harness with the cost model. Then fit the ridge
and LightGBM baselines on `features.parquet`.
