"""Offline tests: parsers on sample payloads, release rules, PIT store, panel lookahead,
feature leakage, and an end-to-end run with a mocked HTTP session."""
import json
import shutil

import numpy as np
import pandas as pd
import pytest
import yaml

from andeanfx.config import load_config
from andeanfx.features import build_features
from andeanfx.panel import build_panel
from andeanfx.sources import BCCh, BCRP, FRED, Socrata
from andeanfx.sources.bcrp import parse_period
from andeanfx.store import PITStore, as_of, knowledge_timeline
from andeanfx.timeutil import apply_release_rule

SNAP = {"time": "12:30", "tz": "America/New_York"}


# ---------------------------------------------------------------- parsers
def test_bcch_parse():
    payload = {"Codigo": 0, "Descripcion": "Success", "Series": {"seriesId": "F073.TCO.PRE.Z.D", "Obs": [
        {"indexDateString": "02-01-2024", "value": "877.12", "statusCode": "OK"},
        {"indexDateString": "03-01-2024", "value": "NaN", "statusCode": "ND"},
        {"indexDateString": "04-01-2024", "value": "880.5", "statusCode": "OK"}]}}
    df = BCCh.parse(payload)
    assert list(df["obs_date"]) == [pd.Timestamp("2024-01-02"), pd.Timestamp("2024-01-04")]
    assert df["value"].tolist() == [877.12, 880.5]


def test_bcrp_parse_and_periods():
    assert parse_period("02.Ene.24") == pd.Timestamp("2024-01-02")
    assert parse_period("15.Set.23") == pd.Timestamp("2023-09-15")
    assert parse_period("Dic.2023") == pd.Timestamp("2023-12-31")
    payload = {"config": {}, "periods": [
        {"name": "02.Ene.24", "values": ["3.705"]},
        {"name": "03.Ene.24", "values": ["n.d."]},
        {"name": "04.Ene.24", "values": ["3.712"]}]}
    df = BCRP.parse(payload)
    assert len(df) == 2 and df["value"].iloc[-1] == 3.712


def test_socrata_expands_ranges():
    rows = [{"valor": "3900.5", "vigenciadesde": "2024-01-06T00:00:00.000", "vigenciahasta": "2024-01-09T00:00:00.000"},
            {"valor": "3910", "vigenciadesde": "2024-01-10T00:00:00.000", "vigenciahasta": "2024-01-10T00:00:00.000"}]
    df = Socrata.parse(rows)
    assert len(df) == 5
    assert df.set_index("obs_date").loc["2024-01-08", "value"] == 3900.5


def test_fred_parse_handles_dots():
    df = FRED.parse("observation_date,DGS2\n2024-01-02,4.33\n2024-01-03,.\n2024-01-04,4.38\n")
    assert len(df) == 2


# ---------------------------------------------------------------- release rules
def test_release_rules():
    d = pd.Series(pd.to_datetime(["2024-01-10"]))  # Wednesday
    trm = apply_release_rule(d, {"type": "lag_bdays", "bdays": -1, "time": "20:00", "tz": "America/Bogota"})
    assert trm.iloc[0] == pd.Timestamp("2024-01-10 01:05", tz="UTC")  # Jan 9 20:00 Bogotá + 5 min
    weekly = apply_release_rule(d, {"type": "weekly", "weekday": 4, "time": "15:30",
                                    "tz": "America/New_York", "min_lag_days": 3})
    assert weekly.iloc[0].tz_convert("America/New_York").date() == pd.Timestamp("2024-01-19").date()
    monthly = apply_release_rule(pd.Series(pd.to_datetime(["2024-01-31"])),
                                 {"type": "monthly_lag", "days": 25, "time": "18:00", "tz": "America/Lima"})
    assert monthly.iloc[0].tz_convert("America/Lima").date() == pd.Timestamp("2024-02-25").date()


# ---------------------------------------------------------------- store
RULE = {"type": "lag_bdays", "bdays": 0, "time": "18:00", "tz": "America/Lima"}


def _df(dates, vals):
    return pd.DataFrame({"obs_date": pd.to_datetime(dates), "value": vals})


def test_store_new_unchanged_and_revision(tmp_path):
    st = PITStore(str(tmp_path))
    t1 = pd.Timestamp("2024-02-01 12:00", tz="UTC")
    r = st.ingest("X", _df(["2024-01-02", "2024-01-03"], [1.0, 2.0]), RULE, fetched_at=t1)
    assert (r.new, r.revised) == (2, 0)
    t2 = pd.Timestamp("2024-02-05 12:00", tz="UTC")
    r = st.ingest("X", _df(["2024-01-02", "2024-01-03", "2024-01-04"], [1.0, 2.5, 3.0]), RULE, fetched_at=t2)
    assert (r.new, r.revised, r.unchanged) == (1, 1, 1)
    h = st.load("X")
    assert h["backfilled"].iloc[0]  # first load was long after release
    # Before the revision was learned we must still see the old value.
    assert as_of(h, t2 - pd.Timedelta(minutes=1))["2024-01-03"] == 2.0
    assert as_of(h, t2)["2024-01-03"] == 2.5
    assert as_of(h, t2, vintage="first")["2024-01-03"] == 2.0
    # Re-ingesting identical data adds nothing.
    r = st.ingest("X", _df(["2024-01-02", "2024-01-03", "2024-01-04"], [1.0, 2.5, 3.0]), RULE,
                  fetched_at=t2 + pd.Timedelta(days=1))
    assert (r.new, r.revised) == (0, 0) and len(st.load("X")) == 4


def test_timeline_uses_newest_obs_not_newest_revision(tmp_path):
    st = PITStore(str(tmp_path))
    st.ingest("X", _df(["2024-01-02", "2024-01-03"], [1.0, 2.0]), RULE, fetched_at=pd.Timestamp("2024-01-04", tz="UTC"))
    # A revision to an OLD date must not replace the newest observation in the panel.
    st.ingest("X", _df(["2024-01-02"], [9.0]), RULE, fetched_at=pd.Timestamp("2024-01-10", tz="UTC"))
    tl = knowledge_timeline(st.load("X"))
    assert tl.iloc[-1]["obs_date"] == pd.Timestamp("2024-01-03") and tl.iloc[-1]["value"] == 2.0


# ---------------------------------------------------------------- panel
def test_panel_respects_publication_time(tmp_path):
    st = PITStore(str(tmp_path))
    # Published 18:00 Lima each day; snapshot 12:30 New York is before that.
    dates = pd.bdate_range("2024-03-01", "2024-03-29")
    st.ingest("PEN", _df(dates, np.arange(len(dates), dtype=float)), RULE,
              fetched_at=pd.Timestamp("2024-04-15", tz="UTC"))
    p = build_panel(st, ["PEN"], "2024-03-04", "2024-03-29", SNAP)
    row = p[p["date"] == "2024-03-12"].iloc[0]
    assert row["PEN__age_d"] == 1  # only yesterday's value is known at the snapshot
    assert row["PEN"] == float(list(dates).index(pd.Timestamp("2024-03-11")))
    mon = p[p["date"] == "2024-03-11"].iloc[0]
    assert mon["PEN__age_d"] == 3  # Monday sees Friday


def test_panel_max_age(tmp_path):
    st = PITStore(str(tmp_path))
    st.ingest("M", _df(["2024-01-31"], [5.0]), RULE, fetched_at=pd.Timestamp("2024-03-01", tz="UTC"))
    p = build_panel(st, ["M"], "2024-02-01", "2024-03-29", SNAP, max_age_days={"M": 30})
    assert p.loc[p["date"] == "2024-02-15", "M"].notna().all()
    assert p.loc[p["date"] == "2024-03-15", "M"].isna().all()


# ---------------------------------------------------------------- features
def _synthetic_panel(n=700, seed=0):
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range("2020-01-01", periods=n)
    copper = 3.5 * np.exp(np.cumsum(rng.normal(0, 0.012, n)))
    brent = 70 * np.exp(np.cumsum(rng.normal(0, 0.02, n)))
    rc, rb = np.diff(np.log(copper), prepend=np.log(copper[0])), np.diff(np.log(brent), prepend=np.log(brent[0]))
    clp = 800 * np.exp(np.cumsum(-0.4 * rc + rng.normal(0, 0.006, n)))
    cop = 4000 * np.exp(np.cumsum(-0.3 * rb + rng.normal(0, 0.008, n)))
    pen = 3.7 * np.exp(np.cumsum(-0.1 * rc + rng.normal(0, 0.003, n)))
    interv = np.where(rng.random(n) < 0.3, rng.normal(-50, 30, n), 0.0)
    p = pd.DataFrame({"date": dates, "CLP_OBSERVADO": clp, "COP_TRM": cop, "PEN_INTERBANK": pen,
                      "COPPER": copper, "BRENT": brent, "VIX": 15 + rng.gamma(2, 2, n),
                      "UST_2Y": 4 + np.cumsum(rng.normal(0, 0.03, n)), "UST_10Y": 4.2 + np.cumsum(rng.normal(0, 0.03, n)),
                      "PEN_BCRP_SPOT_NET": interv, "PEN_BCRP_SPOT_NET__age_d": 1,
                      "COP_OFFSHORE_FWD_NET": np.repeat(rng.normal(0, 1000, n // 5 + 1).cumsum(), 5)[:n]})
    return p


def test_features_build_and_recover_copper_beta():
    f = build_features(_synthetic_panel(), verbose=False)
    assert set(f["ccy"]) == {"CLP", "COP", "PEN"}
    clp = f[f["ccy"] == "CLP"].dropna(subset=["comm_beta_60"])
    assert abs(clp["comm_beta_60"].median() - (-0.4)) < 0.15
    assert "pen_bcrp_spot_net_sum5_scaled" in f.columns
    assert "cop_offshore_fwd_net_chg20_z" in f.columns


def test_features_have_no_lookahead():
    """Features up to date T must be identical whether or not later data exists."""
    p = _synthetic_panel()
    full = build_features(p, verbose=False)
    cut = p["date"].iloc[500]
    trunc = build_features(p[p["date"] <= cut].copy(), verbose=False)
    a = full[full["date"] <= cut].reset_index(drop=True)
    b = trunc.reset_index(drop=True)
    num = [c for c in a.columns if c in b.columns and pd.api.types.is_numeric_dtype(a[c])]
    pd.testing.assert_frame_equal(a[num], b[num], check_exact=False, rtol=1e-10)
    # And perturbing the future does not change the past.
    p2 = p.copy()
    p2.loc[p2["date"] > cut, ["CLP_OBSERVADO", "COPPER"]] *= 1.5
    f2 = build_features(p2, verbose=False)
    pd.testing.assert_frame_equal(f2[f2["date"] <= cut].reset_index(drop=True)[num], a[num], check_exact=False, rtol=1e-10)


# ---------------------------------------------------------------- end to end with mocked HTTP
class FakeResp:
    def __init__(self, payload=None, text=None):
        self.status_code, self._p, self.text = 200, payload, text or ""

    def json(self):
        return self._p


class FakeSession:
    def get(self, url, params=None, **kw):
        days = pd.bdate_range("2023-01-02", "2023-06-30")
        if "bcentral" in url:
            return FakeResp({"Codigo": 0, "Series": {"Obs": [
                {"indexDateString": d.strftime("%d-%m-%Y"), "value": str(850 + i * 0.1), "statusCode": "OK"}
                for i, d in enumerate(days)]}})
        if "bcrp" in url:
            mon = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Set", "Oct", "Nov", "Dic"]
            return FakeResp({"periods": [{"name": f"{d.day:02d}.{mon[d.month - 1]}.{d.year % 100:02d}",
                                          "values": [str(3.7 + i * 0.001)]} for i, d in enumerate(days)]})
        if "datos.gov.co" in url:
            return FakeResp([{"valor": str(4000 + i), "vigenciadesde": d.isoformat(), "vigenciahasta": d.isoformat()}
                             for i, d in enumerate(days)])
        if "fred" in url:
            return FakeResp(text="observation_date,X\n" + "\n".join(f"{d.date()},{4 + i * 0.01}" for i, d in enumerate(days)))
        raise AssertionError(url)


def test_end_to_end(tmp_path, monkeypatch):
    shutil.copytree("config", tmp_path / "config")
    s = yaml.safe_load(open(tmp_path / "config/settings.yaml"))
    s["paths"] = {k: str(tmp_path / v) for k, v in s["paths"].items()}
    s["start"] = "2023-01-02"
    yaml.safe_dump(s, open(tmp_path / "config/settings.yaml", "w"))
    monkeypatch.setenv("BCCH_USER", "u")
    monkeypatch.setenv("BCCH_PASS", "p")
    from andeanfx import pipeline
    cfg = load_config(str(tmp_path / "config"))
    reps = pipeline.fetch(cfg, end="2023-06-30", session=FakeSession(),
                          fetched_at=pd.Timestamp("2023-07-05", tz="UTC"))
    assert all(r[1] == "ok" for r in reps), reps
    p = pipeline.panel(cfg, "2023-02-01", "2023-06-30")
    assert {"CLP_OBSERVADO", "COP_TRM", "PEN_INTERBANK", "UST_2Y"} <= set(p.columns)
    f = build_features(p, verbose=False)
    assert set(f["ccy"]) == {"CLP", "COP", "PEN"}
    st = pipeline.status(cfg)
    assert st.set_index("series").loc["PEN_INTERBANK", "rows"] > 100
