"""Command line.

  python -m andeanfx status                  what is loaded, what needs verifying
  python -m andeanfx check                   list series whose code/release rule must be verified
  python -m andeanfx fetch [--only A,B] [--start YYYY-MM-DD] [--end YYYY-MM-DD]
  python -m andeanfx panel [--start ..] [--end ..]   -> data/out/panel.parquet
  python -m andeanfx features                -> data/out/features.parquet
  python -m andeanfx daily                   fetch + panel + features (schedule this each weekday)
"""
from __future__ import annotations

import argparse
import os

import pandas as pd

from . import pipeline
from .config import load_config
from .features import build_features


def main(argv=None):
    ap = argparse.ArgumentParser(prog="andeanfx")
    ap.add_argument("command", choices=["status", "check", "fetch", "panel", "features", "daily"])
    ap.add_argument("--config", default="config")
    ap.add_argument("--only", help="comma-separated series ids")
    ap.add_argument("--start")
    ap.add_argument("--end")
    a = ap.parse_args(argv)
    cfg = load_config(a.config)
    out_dir = cfg.path("out")
    pd.set_option("display.width", 160)

    if a.command == "status":
        print(pipeline.status(cfg).to_string(index=False))
    elif a.command == "check":
        for s in cfg.series.values():
            if s.verify or s.code == "TODO" or not s.enabled:
                flag = "TODO code" if s.code == "TODO" else ("disabled" if not s.enabled else "verify")
                print(f"  [{flag:9s}] {s.id:24s} {s.source:8s} {s.code:36s} {s.desc}")
    if a.command in ("fetch", "daily"):
        ids = a.only.split(",") if a.only else None
        pipeline.fetch(cfg, ids, a.start, a.end)
    if a.command in ("panel", "daily"):
        p = pipeline.panel(cfg, a.start, a.end, out=os.path.join(out_dir, "panel.parquet"))
        print(f"  panel: {len(p)} snapshots x {len([c for c in p.columns if not c.endswith('__age_d')]) - 1} series")
    if a.command in ("features", "daily"):
        p = pd.read_parquet(os.path.join(out_dir, "panel.parquet"))
        f = build_features(p)
        f.to_parquet(os.path.join(out_dir, "features.parquet"), index=False)
        print(f"  features: {len(f)} rows x {f.shape[1]} columns")


if __name__ == "__main__":
    main()
