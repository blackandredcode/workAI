"""File loader for vendor exports (Bloomberg/LSEG/dealer NDF curves, vol surfaces)
and for central-bank data only published as Excel/CSV (e.g. BanRep derivatives
positions, AFP positions).

`code` is a glob relative to the data/raw folder. Options (from series.yaml):
  date_col, value_col, sheet (Excel), skiprows, dayfirst, decimal, thousands
"""
from __future__ import annotations

import glob
import os

import pandas as pd

from .base import Source, SourceError


class Files(Source):
    name = "file"

    def __init__(self, raw_dir: str = "data/raw", **kw):
        super().__init__(**kw)
        self.raw_dir = raw_dir

    def fetch(self, code: str, start: str, end: str, **opts) -> pd.DataFrame:
        paths = sorted(glob.glob(os.path.join(self.raw_dir, code)))
        if not paths:
            raise SourceError(f"file: no files match {code} in {self.raw_dir}")
        frames = [self.read_one(p, **opts) for p in paths]
        df = pd.concat(frames, ignore_index=True)
        df = self._finish(df)
        mask = (df["obs_date"] >= pd.Timestamp(start)) & (df["obs_date"] <= pd.Timestamp(end))
        return df[mask].reset_index(drop=True)

    @staticmethod
    def read_one(path: str, date_col, value_col, sheet=0, skiprows=None, dayfirst=False,
                 decimal=".", thousands=None, **_) -> pd.DataFrame:
        if path.lower().endswith((".xlsx", ".xls")):
            raw = pd.read_excel(path, sheet_name=sheet, skiprows=skiprows)
        else:
            raw = pd.read_csv(path, skiprows=skiprows, decimal=decimal, thousands=thousands)
        if date_col not in raw.columns or value_col not in raw.columns:
            raise SourceError(f"file: {path} lacks columns {date_col!r}/{value_col!r}; has {list(raw.columns)}")
        return pd.DataFrame({
            "obs_date": pd.to_datetime(raw[date_col], dayfirst=dayfirst, errors="coerce"),
            "value": raw[value_col],
        })
