from __future__ import annotations

import time
from abc import ABC, abstractmethod

import pandas as pd
import requests


class SourceError(RuntimeError):
    pass


class Source(ABC):
    """A data source returns a DataFrame with columns [obs_date, value] for one series.

    obs_date is the reference date (naive, date-only). Publication timing is added
    later by the release rule, so sources stay simple and testable.
    """

    name: str = "base"

    def __init__(self, session: requests.Session | None = None, retries: int = 3, pause: float = 1.0):
        self.session = session or requests.Session()
        self.retries = retries
        self.pause = pause

    def _get(self, url: str, **kwargs) -> requests.Response:
        last = None
        for attempt in range(self.retries):
            try:
                r = self.session.get(url, timeout=60, **kwargs)
                if r.status_code == 200:
                    return r
                last = SourceError(f"{self.name}: HTTP {r.status_code} for {url}")
            except requests.RequestException as e:  # network hiccup
                last = e
            time.sleep(self.pause * (2 ** attempt))
        raise SourceError(f"{self.name}: failed after {self.retries} tries: {last}")

    @abstractmethod
    def fetch(self, code: str, start: str, end: str, **opts) -> pd.DataFrame:
        ...

    @staticmethod
    def _finish(df: pd.DataFrame) -> pd.DataFrame:
        df = df.dropna(subset=["obs_date", "value"])
        df["obs_date"] = pd.to_datetime(df["obs_date"]).dt.normalize()
        df["value"] = pd.to_numeric(df["value"], errors="coerce")
        df = df.dropna(subset=["value"])
        return df.drop_duplicates("obs_date", keep="last").sort_values("obs_date").reset_index(drop=True)
