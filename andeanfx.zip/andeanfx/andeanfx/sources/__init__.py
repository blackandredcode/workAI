from .base import Source, SourceError
from .bcch import BCCh
from .bcrp import BCRP
from .files import Files
from .fred import FRED
from .socrata import Socrata

REGISTRY = {"bcch": BCCh, "bcrp": BCRP, "socrata": Socrata, "fred": FRED, "file": Files}

__all__ = ["Source", "SourceError", "REGISTRY", "BCCh", "BCRP", "Socrata", "FRED", "Files"]
