"""datos.gov.co (Socrata) — used for Colombia's TRM.

TRM dataset: https://www.datos.gov.co/resource/32sa-8pi3.json
Fields: valor, unidad, vigenciadesde, vigenciahasta. One row can cover several days
(weekends/holidays), so rows are expanded to every calendar day in the range and the
obs_date is the date the TRM is in force.
Optional app token in env var SOCRATA_APP_TOKEN raises rate limits.
"""
from __future__ import annotations

import os

import pandas as pd

from .base import Source

BASE = "https://www.datos.gov.co/resource/{dataset}.json"


class Socrata(Source):
    name = "socrata"

    def fetch(self, code: str, start: str, end: str, **opts) -> pd.DataFrame:
        date_field = opts.get("date_field", "vigenciadesde")
        value_field = opts.get("value_field", "valor")
        end_field = opts.get("end_field", "vigenciahasta")
        headers = {}
        if os.environ.get("SOCRATA_APP_TOKEN"):
            headers["X-App-Token"] = os.environ["SOCRATA_APP_TOKEN"]
        rows, offset, limit = [], 0, 50000
        while True:
            params = {"$where": f"{date_field} between '{start}T00:00:00' and '{end}T23:59:59'",
                      "$order": date_field, "$limit": limit, "$offset": offset}
            batch = self._get(BASE.format(dataset=code), params=params, headers=headers).json()
            rows.extend(batch)
            if len(batch) < limit:
                break
            offset += limit
        return self.parse(rows, date_field, value_field, end_field)

    @classmethod
    def parse(cls, rows: list[dict], date_field="vigenciadesde", value_field="valor",
              end_field="vigenciahasta") -> pd.DataFrame:
        out = []
        for r in rows:
            d0 = pd.to_datetime(r.get(date_field), errors="coerce")
            d1 = pd.to_datetime(r.get(end_field), errors="coerce") if end_field else d0
            if pd.isna(d0):
                continue
            d1 = d0 if pd.isna(d1) or d1 < d0 else d1
            for d in pd.date_range(d0.normalize(), d1.normalize(), freq="D"):
                out.append((d, r.get(value_field)))
        return cls._finish(pd.DataFrame(out, columns=["obs_date", "value"]))
