"""Banco Central de Chile — SIETE REST web service.

Needs a free API account (register on the BCCh statistics site). Set credentials
in env vars BCCH_USER and BCCH_PASS.

Endpoint: https://si3.bcentral.cl/SieteRestWS/SieteRestWS.ashx
  ?user=..&pass=..&firstdate=YYYY-MM-DD&lastdate=YYYY-MM-DD&timeseries=CODE&function=GetSeries
Response: {"Codigo": 0, "Descripcion": "Success",
           "Series": {"seriesId": CODE, "Obs": [{"indexDateString": "02-01-2024", "value": "877.12", "statusCode": "OK"}]}}
"""
from __future__ import annotations

import os

import pandas as pd

from .base import Source, SourceError

URL = "https://si3.bcentral.cl/SieteRestWS/SieteRestWS.ashx"


class BCCh(Source):
    name = "bcch"

    def __init__(self, user: str | None = None, password: str | None = None, **kw):
        super().__init__(**kw)
        self.user = user or os.environ.get("BCCH_USER")
        self.password = password or os.environ.get("BCCH_PASS")

    def fetch(self, code: str, start: str, end: str, **opts) -> pd.DataFrame:
        if not (self.user and self.password):
            raise SourceError("bcch: set BCCH_USER and BCCH_PASS")
        params = dict(user=self.user, **{"pass": self.password}, firstdate=start, lastdate=end,
                      timeseries=code, function="GetSeries")
        payload = self._get(URL, params=params).json()
        return self.parse(payload)

    @classmethod
    def parse(cls, payload: dict) -> pd.DataFrame:
        if payload.get("Codigo") not in (0, "0"):
            raise SourceError(f"bcch: {payload.get('Descripcion')}")
        obs = (payload.get("Series") or {}).get("Obs") or []
        rows = [(o.get("indexDateString"), o.get("value")) for o in obs
                if str(o.get("statusCode", "OK")).upper() == "OK"]
        df = pd.DataFrame(rows, columns=["obs_date", "value"])
        df["obs_date"] = pd.to_datetime(df["obs_date"], format="%d-%m-%Y", errors="coerce")
        df["value"] = df["value"].astype(str).str.replace(",", ".", regex=False)
        return cls._finish(df)
