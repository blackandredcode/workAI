"""Banco Central de Reserva del Perú — BCRPData API (no key).

Endpoint: https://estadisticas.bcrp.gob.pe/estadisticas/series/api/{CODE}/json/{start}/{end}
Daily periods look like "02.Ene.24"; monthly like "Ene.2024"; missing values are "n.d.".
"""
from __future__ import annotations

import re

import pandas as pd

from .base import Source, SourceError

URL = "https://estadisticas.bcrp.gob.pe/estadisticas/series/api/{code}/json/{start}/{end}"

MONTHS = {"ene": 1, "feb": 2, "mar": 3, "abr": 4, "may": 5, "jun": 6, "jul": 7, "ago": 8,
          "sep": 9, "set": 9, "oct": 10, "nov": 11, "dic": 12}


def parse_period(s: str):
    s = s.strip()
    m = re.fullmatch(r"(\d{1,2})\.(\w{3})\.(\d{2,4})", s)  # daily
    if m:
        d, mon, y = int(m[1]), MONTHS[m[2].lower()], int(m[3])
        y = y + 2000 if y < 100 else y
        return pd.Timestamp(y, mon, d)
    m = re.fullmatch(r"(\w{3})\.(\d{4})", s)  # monthly: stamp at month end
    if m:
        return pd.Timestamp(int(m[2]), MONTHS[m[1].lower()], 1) + pd.offsets.MonthEnd(0)
    m = re.fullmatch(r"(\d{4})", s)  # annual
    if m:
        return pd.Timestamp(int(m[1]), 12, 31)
    return pd.NaT


class BCRP(Source):
    name = "bcrp"

    def fetch(self, code: str, start: str, end: str, **opts) -> pd.DataFrame:
        freq = opts.get("freq", "D")
        fmt = {"D": "%Y-%m-%d", "M": "%Y-%m", "A": "%Y"}[freq]
        url = URL.format(code=code, start=pd.Timestamp(start).strftime(fmt), end=pd.Timestamp(end).strftime(fmt))
        r = self._get(url)
        try:
            payload = r.json()
        except ValueError as e:
            raise SourceError(f"bcrp: non-JSON response for {code} (bad code?)") from e
        return self.parse(payload)

    @classmethod
    def parse(cls, payload: dict) -> pd.DataFrame:
        rows = []
        for p in payload.get("periods", []):
            v = (p.get("values") or [None])[0]
            if v is None or str(v).strip().lower() in ("n.d.", "nd", ""):
                continue
            rows.append((parse_period(p["name"]), v))
        return cls._finish(pd.DataFrame(rows, columns=["obs_date", "value"]))
