"""FRED — US rates, dollar index, Brent, copper (monthly IMF series).

Uses the public CSV endpoint (no key): https://fred.stlouisfed.org/graph/fredgraph.csv?id=CODE
"""
from __future__ import annotations

import io

import pandas as pd

from .base import Source

URL = "https://fred.stlouisfed.org/graph/fredgraph.csv"


class FRED(Source):
    name = "fred"

    def fetch(self, code: str, start: str, end: str, **opts) -> pd.DataFrame:
        r = self._get(URL, params={"id": code, "cosd": start, "coed": end})
        return self.parse(r.text)

    @classmethod
    def parse(cls, text: str) -> pd.DataFrame:
        df = pd.read_csv(io.StringIO(text))
        df.columns = ["obs_date", "value"] + list(df.columns[2:])
        df = df[["obs_date", "value"]].replace(".", pd.NA)
        return cls._finish(df)
