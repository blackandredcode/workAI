"""Build a daily as-of panel: one row per decision snapshot, one column per series,
holding the newest value that was actually available at that moment."""
from __future__ import annotations

import pandas as pd

from .store import PITStore, knowledge_timeline
from .timeutil import snapshot_times


def build_panel(store: PITStore, series_ids: list[str], start: str, end: str, snapshot: dict,
                vintage: str = "latest", max_age_days: dict[str, float] | None = None,
                with_age: bool = True) -> pd.DataFrame:
    """Return a DataFrame indexed by snapshot time (UTC) with a value column per series
    and, if with_age, a '<id>__age_d' column: days between the snapshot and the obs_date used."""
    snaps = snapshot_times(start, end, snapshot)
    base = pd.DataFrame({"snapshot": snaps}).sort_values("snapshot")
    out = base.set_index("snapshot")
    max_age_days = max_age_days or {}
    for sid in series_ids:
        tl = knowledge_timeline(store.load(sid), vintage)
        if tl.empty:
            out[sid] = float("nan")
            continue
        tl = tl.sort_values("available_at")
        tl["available_at"] = pd.to_datetime(tl["available_at"], utc=True)
        m = pd.merge_asof(base, tl, left_on="snapshot", right_on="available_at", direction="backward")
        m = m.set_index("snapshot")
        age = (m.index.tz_convert(snapshot["tz"]).tz_localize(None).normalize() - m["obs_date"]).dt.days
        vals = m["value"].astype(float)
        lim = max_age_days.get(sid)
        if lim is not None:
            vals = vals.where(age <= lim)
        out[sid] = vals
        if with_age:
            out[f"{sid}__age_d"] = age
        # Defensive: the value used must have been available at the snapshot.
        assert (m["available_at"].isna() | (m["available_at"] <= m.index)).all(), f"lookahead in {sid}"
    out.index.name = "snapshot_utc"
    out.insert(0, "date", out.index.tz_convert(snapshot["tz"]).tz_localize(None).normalize())
    return out
