"""Publication-time rules.

Most central-bank APIs return values keyed by *reference date* only, not by the
moment the value became public. For backtests we must know the latter, so every
series carries a release rule that maps obs_date -> available_at (UTC).

Rule forms (in series.yaml, key `release`):

  {type: lag_bdays, bdays: 0, time: "13:30", tz: "America/Lima"}
      available on obs_date + N business days at local time. N may be negative
      (e.g. Colombia's TRM for date d is published on business day d-1).
  {type: weekly, weekday: 4, time: "15:30", tz: "America/New_York", min_lag_days: 3}
      available on the first given weekday (Mon=0) at least min_lag_days after obs_date.
  {type: monthly_lag, days: 30, time: "09:00", tz: "America/Santiago"}
      available `days` calendar days after the end of the reference month.
  {type: snapshot}
      vendor exports: value observed at the snapshot itself, available at obs_date + snapshot time.

Every rule also accepts `buffer_min` (default 5) added to the result.
Rules are deliberately conservative. Verify them against real release calendars.
"""
from __future__ import annotations

import pandas as pd
from pandas.tseries.offsets import BDay


def _at_local(dates: pd.DatetimeIndex, time_str: str, tz: str) -> pd.DatetimeIndex:
    hh, mm = (int(x) for x in time_str.split(":"))
    local = dates.normalize() + pd.Timedelta(hours=hh, minutes=mm)
    return local.tz_localize(tz, nonexistent="shift_forward", ambiguous="NaT").tz_convert("UTC")


def apply_release_rule(obs_dates: pd.Series, rule: dict, snapshot: dict | None = None) -> pd.Series:
    """Return a UTC timestamp Series of when each observation became usable."""
    d = pd.DatetimeIndex(pd.to_datetime(obs_dates))
    kind = rule["type"]
    buffer = pd.Timedelta(minutes=rule.get("buffer_min", 5))

    if kind == "lag_bdays":
        shifted = d + BDay(rule.get("bdays", 0)) if rule.get("bdays", 0) else d
        out = _at_local(pd.DatetimeIndex(shifted), rule["time"], rule["tz"])
    elif kind == "weekly":
        target = int(rule["weekday"])
        earliest = d + pd.Timedelta(days=int(rule.get("min_lag_days", 0)))
        delta = (target - earliest.weekday) % 7
        out = _at_local(earliest + pd.to_timedelta(delta, unit="D"), rule["time"], rule["tz"])
    elif kind == "monthly_lag":
        month_end = d + pd.offsets.MonthEnd(0)
        out = _at_local(month_end + pd.Timedelta(days=int(rule["days"])), rule["time"], rule["tz"])
    elif kind == "snapshot":
        snap = snapshot or {"time": "12:30", "tz": "America/New_York"}
        out = _at_local(d, snap["time"], snap["tz"])
    else:
        raise ValueError(f"unknown release rule type: {kind}")

    return pd.Series(out + buffer, index=obs_dates.index, name="available_at")


def snapshot_times(start: str, end: str, snapshot: dict, calendar: str = "B") -> pd.DatetimeIndex:
    """UTC decision timestamps, one per business day."""
    days = pd.date_range(start, end, freq=calendar)
    return _at_local(days, snapshot["time"], snapshot["tz"])
