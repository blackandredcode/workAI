from __future__ import annotations

import os
from dataclasses import dataclass, field

import yaml

REQUIRED = ("source", "code", "release")


@dataclass
class SeriesSpec:
    id: str
    source: str
    code: str
    release: dict
    desc: str = ""
    freq: str = "D"
    opts: dict = field(default_factory=dict)
    max_age_days: float | None = None
    enabled: bool = True
    verify: bool = False


@dataclass
class Config:
    settings: dict
    series: dict[str, SeriesSpec]

    @property
    def snapshot(self) -> dict:
        return self.settings["snapshot"]

    def path(self, key: str) -> str:
        return self.settings["paths"][key]

    def enabled(self) -> list[SeriesSpec]:
        return [s for s in self.series.values() if s.enabled and s.code != "TODO"]


def load_config(config_dir: str = "config") -> Config:
    with open(os.path.join(config_dir, "settings.yaml")) as f:
        settings = yaml.safe_load(f)
    with open(os.path.join(config_dir, "series.yaml")) as f:
        raw = yaml.safe_load(f)["series"]
    series = {}
    for sid, d in raw.items():
        missing = [k for k in REQUIRED if k not in d]
        if missing:
            raise ValueError(f"series {sid} missing {missing}")
        series[sid] = SeriesSpec(id=sid, **{k: v for k, v in d.items() if k in SeriesSpec.__dataclass_fields__})
    return Config(settings, series)
