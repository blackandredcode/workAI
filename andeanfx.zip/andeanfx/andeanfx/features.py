"""Starter P1 features from the as-of panel.

Every feature at snapshot t uses only panel rows <= t (rolling windows, past-only betas).
Output is long format: one row per (date, ccy).

Missing inputs are skipped with a note, so this runs on whatever series you have loaded.
Note: rolling windows run over the as-of panel, so a revision to an old value only enters
from the day it was learned. That is the PIT-correct behaviour.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

CCYS = ["CLP", "COP", "PEN"]

# Price column preference per currency: first one present with data wins (whole column,
# never mixed row by row, to avoid level jumps between sources).
PRICE = {
    "CLP": ["CLP_SPOT_ONSHORE", "CLP_OBSERVADO", "CLP_NDF_1M"],
    "COP": ["COP_SPOT_ONSHORE", "COP_TRM", "COP_NDF_1M"],
    "PEN": ["PEN_INTERBANK", "PEN_NDF_1M"],
}
SPOT_FOR_CARRY = {"CLP": "CLP_SPOT_ONSHORE", "COP": "COP_SPOT_ONSHORE", "PEN": "PEN_INTERBANK"}
NDF_1M = {c: f"{c}_NDF_1M" for c in CCYS}
COMMODITY = {"CLP": "COPPER", "PEN": "COPPER", "COP": "BRENT"}
FLOWS = {"CLP": ["CLP_AFP_FWD_NET"], "COP": ["COP_OFFSHORE_FWD_NET", "COP_AFP_FWD_NET"], "PEN": ["PEN_AFP_FX"]}
INTERVENTION = {"PEN": ["PEN_BCRP_SPOT_NET", "PEN_BCRP_FX_SWAPS_NET"]}


def _has(p: pd.DataFrame, col: str) -> bool:
    return col in p.columns and p[col].notna().sum() > 0


def _z(x: pd.Series, win: int = 250, minp: int = 60) -> pd.Series:
    m = x.rolling(win, min_periods=minp).mean()
    s = x.rolling(win, min_periods=minp).std()
    return (x - m) / s.replace(0, np.nan)


def _new_obs_only(p: pd.DataFrame, col: str) -> pd.Series:
    """Value only on snapshots where a new observation arrived (avoid double counting ffilled flows)."""
    age = p.get(f"{col}__age_d")
    if age is None:
        return p[col]
    obs_date = p["date"] - pd.to_timedelta(age, unit="D")
    fresh = obs_date.ne(obs_date.shift())
    return p[col].where(fresh, 0.0)


def _past_beta(y: pd.Series, x: pd.Series, win: int = 60) -> pd.Series:
    """Rolling OLS beta of y on x, estimated on the window ending at t-1."""
    cov = y.rolling(win, min_periods=win // 2).cov(x)
    var = x.rolling(win, min_periods=win // 2).var()
    return (cov / var.replace(0, np.nan)).shift(1)


def build_features(panel: pd.DataFrame, verbose: bool = True) -> pd.DataFrame:
    p = panel.reset_index(drop=True)
    notes, frames = [], []

    glob = pd.DataFrame(index=p.index)
    if _has(p, "VIX"):
        glob["vix_log"] = np.log(p["VIX"])
        glob["vix_z"] = _z(p["VIX"])
    if _has(p, "UST_2Y"):
        glob["ust2y_chg5"] = p["UST_2Y"].diff(5)
    if _has(p, "UST_10Y") and _has(p, "UST_2Y"):
        glob["ust_2s10s"] = p["UST_10Y"] - p["UST_2Y"]
    if _has(p, "US_HY_OAS"):
        glob["hy_oas_chg5"] = p["US_HY_OAS"].diff(5)
    if _has(p, "USD_BROAD"):
        glob["usd_ret20"] = np.log(p["USD_BROAD"]).diff(20)
    glob["dow"] = p["date"].dt.dayofweek
    glob["bdays_to_month_end"] = [len(pd.bdate_range(d, d + pd.offsets.MonthEnd(0))) - 1 for d in p["date"]]

    for ccy in CCYS:
        f = pd.DataFrame({"date": p["date"], "ccy": ccy})
        price_col = next((c for c in PRICE[ccy] if _has(p, c)), None)
        if price_col is None:
            notes.append(f"{ccy}: no price series loaded, skipped")
            continue
        f["price_source"] = price_col
        lp = np.log(p[price_col])
        r1 = lp.diff()
        sig60 = r1.rolling(60, min_periods=40).std()
        f["ret_1"], f["ret_5"], f["ret_20"] = r1, lp.diff(5), lp.diff(20)
        for k in (20, 60, 120):
            f[f"mom_{k}"] = (lp.diff(k) / (sig60 * np.sqrt(k))).clip(-4, 4)
        for w in (20, 60):
            f[f"rv_{w}_log"] = np.log(r1.rolling(w, min_periods=int(w * 0.75)).std() * np.sqrt(252))
        f["jump_flag"] = (r1.abs() > 3 * sig60.shift(1)).astype(float)
        f["ma50_dist"] = (p[price_col] - p[price_col].rolling(50, min_periods=40).mean()) / (
            sig60 * p[price_col])

        com = COMMODITY[ccy]
        if _has(p, com):
            rc = np.log(p[com]).diff()
            beta = _past_beta(r1, rc)
            resid = r1 - beta * rc
            cum = resid.rolling(20, min_periods=15).sum()
            f["comm_beta_60"] = beta
            f["comm_resid_z"] = cum / (resid.rolling(250, min_periods=120).std() * np.sqrt(20))
        else:
            notes.append(f"{ccy}: commodity {com} missing, commodity features skipped")

        spot, ndf = SPOT_FOR_CARRY[ccy], NDF_1M[ccy]
        if _has(p, spot) and _has(p, ndf) and _has(p, "SOFR"):
            tau, usd = 1 / 12, p["SOFR"] / 100
            implied = ((p[ndf] / p[spot]) * (1 + usd * tau) - 1) / tau
            f["carry_1m"] = implied - usd
            f["carry_to_vol"] = f["carry_1m"] / (r1.rolling(60, min_periods=40).std() * np.sqrt(252))
        else:
            notes.append(f"{ccy}: need {spot}, {ndf}, SOFR for carry; skipped")

        for col in FLOWS.get(ccy, []):
            if _has(p, col):
                lvl = p[col]
                f[f"{col.lower()}_chg20_z"] = _z(lvl.diff(20))
                f[f"{col.lower()}_lvl_z"] = _z(lvl, win=750, minp=120)
            else:
                notes.append(f"{ccy}: flow series {col} not loaded")

        for col in INTERVENTION.get(ccy, []):
            if _has(p, col):
                daily = _new_obs_only(p, col)
                scale = daily.rolling(250, min_periods=60).std().replace(0, np.nan)
                for w in (1, 5, 20):
                    f[f"{col.lower()}_sum{w}_scaled"] = daily.rolling(w, min_periods=1).sum() / scale
                f[f"{col.lower()}_active_share20"] = (daily != 0).astype(float).rolling(20, min_periods=5).mean()
            else:
                notes.append(f"{ccy}: intervention series {col} not loaded")

        frames.append(pd.concat([f, glob], axis=1))

    if verbose:
        for n in notes:
            print("  note:", n)
    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True).sort_values(["date", "ccy"]).reset_index(drop=True)
