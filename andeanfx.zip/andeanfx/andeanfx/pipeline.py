from __future__ import annotations

import os

import pandas as pd

from .config import Config
from .panel import build_panel
from .sources import REGISTRY, SourceError
from .store import PITStore


def make_store(cfg: Config) -> PITStore:
    return PITStore(cfg.path("pit"), grace=pd.Timedelta(days=cfg.settings.get("backfill_grace_days", 3)))


def make_source(cfg: Config, name: str, session=None):
    cls = REGISTRY[name]
    if name == "file":
        return cls(raw_dir=cfg.path("raw"), session=session)
    return cls(session=session)


def fetch(cfg: Config, ids: list[str] | None = None, start: str | None = None, end: str | None = None,
          session=None, fetched_at: pd.Timestamp | None = None) -> list:
    store = make_store(cfg)
    start = start or cfg.settings["start"]
    end = end or pd.Timestamp.today().strftime("%Y-%m-%d")
    specs = [s for s in cfg.enabled() if ids is None or s.id in ids]
    sources, reports = {}, []
    for s in specs:
        src = sources.setdefault(s.source, make_source(cfg, s.source, session))
        try:
            df = src.fetch(s.code, start, end, freq=s.freq, **s.opts)
        except SourceError as e:
            print(f"  FAIL {s.id}: {e}")
            reports.append((s.id, "fail", str(e)))
            continue
        rep = store.ingest(s.id, df, s.release, fetched_at=fetched_at, snapshot=cfg.snapshot)
        print(f"  ok   {s.id:24s} new={rep.new:6d} revised={rep.revised:4d} unchanged={rep.unchanged:6d}")
        reports.append((s.id, "ok", rep))
    return reports


def panel(cfg: Config, start: str | None = None, end: str | None = None, out: str | None = None) -> pd.DataFrame:
    store = make_store(cfg)
    ids = [s for s in store.series_ids() if s in cfg.series]
    p = build_panel(store, ids, start or cfg.settings["start"], end or pd.Timestamp.today().strftime("%Y-%m-%d"),
                    cfg.snapshot, vintage=cfg.settings.get("vintage", "latest"),
                    max_age_days={s: cfg.series[s].max_age_days for s in ids if cfg.series[s].max_age_days})
    if out:
        os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
        p.to_parquet(out)
    return p


def status(cfg: Config) -> pd.DataFrame:
    store = make_store(cfg)
    rows = []
    for sid, spec in cfg.series.items():
        h = store.load(sid)
        rows.append({
            "series": sid, "enabled": spec.enabled and spec.code != "TODO", "verify": spec.verify,
            "rows": len(h),
            "first_obs": h["obs_date"].min() if len(h) else None,
            "last_obs": h["obs_date"].max() if len(h) else None,
            "revisions": int(h["is_revision"].sum()) if len(h) else 0,
            "pct_backfilled": round(100 * h["backfilled"].mean(), 1) if len(h) else None,
        })
    return pd.DataFrame(rows)
