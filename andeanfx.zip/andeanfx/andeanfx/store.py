"""Point-in-time (PIT) store.

One Parquet file per series with every vintage ever seen:

    obs_date      reference date the value describes
    value
    available_at  UTC time the value could first have been used
    fetched_at    UTC time this pipeline downloaded it
    backfilled    True if available_at came from the release rule rather than being seen live
    is_revision   True if this row changed an earlier value for the same obs_date

Rules:
  * First sighting of an obs_date: available_at = release-rule time.
    If we fetched it more than `grace` after that, it is marked backfilled.
  * A changed value for a known obs_date is a revision: available_at = fetched_at.
  * Unchanged values are not stored again. Nothing is ever overwritten or deleted.
"""
from __future__ import annotations

import os
from dataclasses import dataclass

import numpy as np
import pandas as pd

from .timeutil import apply_release_rule

COLS = ["obs_date", "value", "available_at", "fetched_at", "backfilled", "is_revision"]


@dataclass
class IngestReport:
    series_id: str
    new: int
    revised: int
    unchanged: int


class PITStore:
    def __init__(self, root: str = "data/pit", grace: pd.Timedelta = pd.Timedelta(days=3), rtol: float = 1e-9):
        self.root = root
        self.grace = grace
        self.rtol = rtol
        os.makedirs(root, exist_ok=True)

    def path(self, series_id: str) -> str:
        return os.path.join(self.root, f"{series_id}.parquet")

    def load(self, series_id: str) -> pd.DataFrame:
        p = self.path(series_id)
        if not os.path.exists(p):
            return pd.DataFrame({c: pd.Series(dtype=t) for c, t in zip(
                COLS, ["datetime64[ns]", "float64", "datetime64[ns, UTC]", "datetime64[ns, UTC]", "bool", "bool"])})
        return pd.read_parquet(p)

    def series_ids(self) -> list[str]:
        return sorted(f[:-8] for f in os.listdir(self.root) if f.endswith(".parquet"))

    def ingest(self, series_id: str, df: pd.DataFrame, rule: dict, fetched_at: pd.Timestamp | None = None,
               snapshot: dict | None = None) -> IngestReport:
        fetched_at = (fetched_at or pd.Timestamp.now(tz="UTC")).tz_convert("UTC")
        hist = self.load(series_id)
        latest = (hist.sort_values("available_at").groupby("obs_date")["value"].last()
                  if len(hist) else pd.Series(dtype=float))

        df = df[["obs_date", "value"]].copy()
        df["obs_date"] = pd.to_datetime(df["obs_date"]).dt.normalize()
        prev = df["obs_date"].map(latest)
        is_new = prev.isna()
        changed = ~is_new & ~np.isclose(df["value"], prev.astype(float), rtol=self.rtol, atol=0)

        new_rows = df[is_new].copy()
        if len(new_rows):
            rule_t = apply_release_rule(new_rows["obs_date"], rule, snapshot)
            new_rows["available_at"] = rule_t
            new_rows["backfilled"] = (fetched_at - rule_t) > self.grace
            new_rows["is_revision"] = False
        rev_rows = df[changed].copy()
        if len(rev_rows):
            rev_rows["available_at"] = fetched_at
            rev_rows["backfilled"] = False
            rev_rows["is_revision"] = True

        add = pd.concat([new_rows, rev_rows], ignore_index=True)
        if len(add):
            add["fetched_at"] = fetched_at
            out = pd.concat([hist, add[COLS]], ignore_index=True) if len(hist) else add[COLS]
            out.sort_values(["obs_date", "available_at"]).to_parquet(self.path(series_id), index=False)
        return IngestReport(series_id, int(is_new.sum()), int(changed.sum()), int((~is_new & ~changed).sum()))


def knowledge_timeline(hist: pd.DataFrame, vintage: str = "latest") -> pd.DataFrame:
    """Turn a vintage history into a step function of 'what did we know, when'.

    Returns rows [available_at, obs_date, value]: from available_at onward, the newest
    known observation was obs_date with this value.
      vintage='latest' -> use the latest revision known at the time (PIT-correct)
      vintage='first'  -> always use the first-release value (ignores revisions)
    """
    if hist.empty:
        return pd.DataFrame(columns=["available_at", "obs_date", "value"])
    h = hist.sort_values(["available_at", "obs_date"])
    if vintage == "first":
        h = h[~h["is_revision"].astype(bool)]
    known: dict = {}
    max_obs = None
    out = []
    for t, d, v in zip(h["available_at"], h["obs_date"], h["value"]):
        known[d] = v
        if max_obs is None or d > max_obs:
            max_obs = d
        out.append((t, max_obs, known[max_obs]))
    tl = pd.DataFrame(out, columns=["available_at", "obs_date", "value"])
    return tl.drop_duplicates("available_at", keep="last").reset_index(drop=True)


def as_of(hist: pd.DataFrame, t: pd.Timestamp, vintage: str = "latest") -> pd.Series:
    """Full series (obs_date -> value) exactly as it was known at time t."""
    h = hist[hist["available_at"] <= t]
    if vintage == "first":
        h = h[~h["is_revision"].astype(bool)]
    return h.sort_values("available_at").groupby("obs_date")["value"].last()
