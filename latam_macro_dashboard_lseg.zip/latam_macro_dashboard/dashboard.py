"""
Streamlit LatAm Macro Dashboard

Run:
    streamlit run dashboard.py
"""

from pathlib import Path
import pandas as pd
import numpy as np
import plotly.express as px
import streamlit as st

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"

st.set_page_config(
    page_title="LatAm Macro Monitor",
    page_icon="🌎",
    layout="wide",
)

st.title("🌎 LatAm Macro Monitor")
st.caption("Brazil · Mexico · Colombia · Chile · Peru | LSEG historical + consensus")

master_path = DATA / "macro_master.parquet"
events_path = DATA / "forecast_events.parquet"

if not master_path.exists():
    st.warning("No macro_master.parquet found. Run `python macro_pipeline.py` first.")
    st.stop()

df = pd.read_parquet(master_path)
df["date"] = pd.to_datetime(df["date"])

countries = sorted(df["country"].dropna().unique())
indicators = sorted(df["indicator"].dropna().unique())

country = st.sidebar.selectbox("Country", countries)
indicator = st.sidebar.selectbox("Indicator", indicators)

country_df = df[df["country"] == country].copy()
series = country_df[country_df["indicator"] == indicator].sort_values("date")

latest = series.iloc[-1] if not series.empty else None

# ---------------- KPIs ----------------
c1, c2, c3, c4 = st.columns(4)

if latest is not None:
    c1.metric("Latest", f"{latest['value']:.2f}", f"{latest['unit']}")
    c2.metric("MoM change", f"{latest['mom_change']:.2f}%" if pd.notna(latest["mom_change"]) else "n/a")
    c3.metric("YoY change", f"{latest['yoy_change']:.2f}%" if pd.notna(latest["yoy_change"]) else "n/a")
    c4.metric("Observation date", latest["date"].strftime("%Y-%m-%d"))

st.divider()

# ---------------- Trend ----------------
left, right = st.columns([2, 1])

with left:
    st.subheader(f"{country} — {indicator}")
    fig = px.line(
        series,
        x="date",
        y="value",
        markers=True,
        labels={"value": indicator, "date": ""},
        template="plotly_white",
    )
    fig.update_layout(height=430, hovermode="x unified")
    st.plotly_chart(fig, use_container_width=True)

with right:
    st.subheader("Latest indicators")
    snap = (
        country_df.sort_values("date")
        .groupby("indicator", as_index=False)
        .tail(1)
        [["indicator", "value", "unit", "date"]]
        .sort_values("indicator")
    )
    snap["value"] = snap["value"].round(2)
    snap["date"] = snap["date"].dt.strftime("%Y-%m-%d")
    st.dataframe(snap, use_container_width=True, hide_index=True)

# ---------------- Country heatmap ----------------
st.subheader("Country Macro Snapshot")

snap_all = (
    df.sort_values("date")
      .groupby(["country", "indicator"], as_index=False)
      .tail(1)
)

pivot = snap_all.pivot(index="country", columns="indicator", values="value")
st.dataframe(pivot.round(2), use_container_width=True)

# ---------------- Consensus / forecast ----------------
if events_path.exists():
    events = pd.read_parquet(events_path)
    st.subheader("Latest LSEG Economic-Event Consensus")

    # Try to identify country from indicator name if country isn't explicitly
    # present in the event file.
    event_text = events.astype(str).agg(" ".join, axis=1)
    filtered = events[event_text.str.contains(country, case=False, na=False)]

    if filtered.empty:
        filtered = events

    show_cols = [
        c for c in [
            "Instrument", "TR.IndicatorName", "event_date",
            "forecast_period", "actual", "consensus", "prior", "revision"
        ] if c in filtered.columns
    ]

    if show_cols:
        st.dataframe(
            filtered.sort_values("event_date", ascending=False)[show_cols].head(30),
            use_container_width=True,
            hide_index=True,
        )
    else:
        st.info("Consensus file exists, but its columns need mapping in dashboard.py.")
else:
    st.info(
        "Consensus/forecast layer not loaded. Export the relevant Economic Monitor "
        "event RICs from Workspace and run the pipeline with those RICs."
    )

st.divider()
st.caption(
    "Data source: LSEG Datastream / LSEG Data Library. "
    "Historical series and economic-event consensus are kept separate."
)
