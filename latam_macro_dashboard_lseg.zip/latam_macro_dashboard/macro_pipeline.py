"""
LatAm Macro Data Pipeline - LSEG

Two LSEG data layers are deliberately separated:
1) Datastream Web Service (DatastreamPy) -> historical macro time series.
2) LSEG Data Library (lseg.data) -> economic-event actual/prior/consensus data.

This avoids pretending that an economic-calendar consensus field is a
long-run annual forecast. For annual/quarterly forward forecasts, add the
appropriate LSEG forecast series to series.csv after identifying it in
Workspace/Datastream.

Expected output:
data/raw_history.parquet
data/forecast_events.parquet
data/macro_master.parquet
data/latest_country_snapshot.parquet
"""

from __future__ import annotations

import os
from pathlib import Path
from datetime import date, timedelta
import pandas as pd
import numpy as np
from dotenv import load_dotenv

load_dotenv()

ROOT = Path(__file__).resolve().parent
CONFIG = ROOT / "config"
DATA = ROOT / "data"
DATA.mkdir(exist_ok=True)

COUNTRY_ALIASES = {
    "Brazil": "Brazil",
    "Mexico": "Mexico",
    "Colombia": "Colombia",
    "Chile": "Chile",
    "Peru": "Peru",
}

def load_series_config() -> pd.DataFrame:
    path = CONFIG / "series.csv"
    df = pd.read_csv(path)
    df["country"] = df["country"].replace(COUNTRY_ALIASES)
    return df

def fetch_datastream_history(cfg: pd.DataFrame, years: int = 3) -> pd.DataFrame:
    """
    Retrieve historical observations using DatastreamPy.

    Only rows with a non-empty datastream_symbol are requested.
    Datastream supports historical time series with start/end/frequency.
    """
    try:
        import DatastreamPy as DSWS
    except ImportError as exc:
        raise RuntimeError(
            "Install DatastreamPy or use the LSEG environment that provides it."
        ) from exc

    user = os.getenv("DS_USERNAME")
    password = os.getenv("DS_PASSWORD")
    if not user or not password:
        raise RuntimeError("Set DS_USERNAME and DS_PASSWORD in .env")

    ds = DSWS.DataClient(None, username=user, password=password)

    end = pd.Timestamp.today().normalize()
    start = end - pd.DateOffset(years=years)

    rows = []
    active = cfg[cfg["datastream_symbol"].notna() &
                (cfg["datastream_symbol"].astype(str).str.strip() != "")].copy()

    for _, r in active.iterrows():
        symbol = str(r["datastream_symbol"]).strip()
        freq = str(r["frequency"]).strip().upper()

        try:
            raw = ds.get_data(
                tickers=symbol,
                start=start.strftime("%Y-%m-%d"),
                end=end.strftime("%Y-%m-%d"),
                freq=freq,
            )

            if raw is None or len(raw) == 0:
                continue

            x = raw.copy()
            x = x.reset_index()

            # Datastream commonly returns the date in the index and the
            # series name/symbol as a column. Normalize defensively.
            date_col = x.columns[0]
            value_col = x.columns[-1]

            out = pd.DataFrame({
                "date": pd.to_datetime(x[date_col], errors="coerce"),
                "country": r["country"],
                "iso": r["iso"],
                "indicator": r["indicator"],
                "unit": r["unit"],
                "frequency": r["frequency"],
                "value": pd.to_numeric(x[value_col], errors="coerce"),
                "source": "LSEG Datastream",
                "symbol": symbol,
            }).dropna(subset=["date", "value"])

            rows.append(out)

        except Exception as exc:
            print(f"[WARN] {r['country']} / {r['indicator']} / {symbol}: {exc}")

    if not rows:
        return pd.DataFrame(
            columns=[
                "date", "country", "iso", "indicator", "unit",
                "frequency", "value", "source", "symbol"
            ]
        )

    result = pd.concat(rows, ignore_index=True)
    result = result.sort_values(["country", "indicator", "date"])
    result.to_parquet(DATA / "raw_history.parquet", index=False)
    return result

def fetch_economic_event_consensus(event_rics: list[str]) -> pd.DataFrame:
    """
    Pull LSEG Economic Monitor event observations.

    The fields below are the LSEG examples for economic-event data:
      ECI_ACT_DT, FCAST_PRD, ECON_ACT, RTR_POLL, ECON_PRIOR, ECON_REV

    event_rics should be exported from Workspace Economic Monitor for the
    selected LatAm countries/indicators.
    """
    import lseg.data as ld

    ld.open_session()

    fields = [
        "TR.IndicatorName",
        "TR.IndicatorType",
        "TR.IndicatorSource",
        "ECI_ACT_DT",
        "ACT_VAL_NS",
        "FCAST_PRD",
        "ECON_ACT",
        "RTR_POLL",
        "ECON_PRIOR",
        "ECON_REV",
    ]

    df = ld.get_data(universe=event_rics, fields=fields)
    df = df.reset_index(drop=False)

    rename = {
        "ECI_ACT_DT": "event_date",
        "FCAST_PRD": "forecast_period",
        "ECON_ACT": "actual",
        "RTR_POLL": "consensus",
        "ECON_PRIOR": "prior",
        "ECON_REV": "revision",
    }
    df = df.rename(columns=rename)

    for c in ["event_date", "actual", "consensus", "prior", "revision"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="ignore")

    df.to_parquet(DATA / "forecast_events.parquet", index=False)
    return df

def build_features(history: pd.DataFrame) -> pd.DataFrame:
    if history.empty:
        return history

    df = history.sort_values(["country", "indicator", "date"]).copy()

    g = df.groupby(["country", "indicator"], group_keys=False)

    df["mom_change"] = g["value"].pct_change(1) * 100
    df["yoy_change"] = g["value"].pct_change(12) * 100
    df["delta_3m"] = g["value"].diff(3)
    df["delta_12m"] = g["value"].diff(12)
    df["z_36m"] = (
        (df["value"] - g["value"].transform(lambda x: x.rolling(36, min_periods=12).mean()))
        / g["value"].transform(lambda x: x.rolling(36, min_periods=12).std())
    )

    df.to_parquet(DATA / "macro_master.parquet", index=False)
    return df

def latest_snapshot(master: pd.DataFrame) -> pd.DataFrame:
    if master.empty:
        return master

    x = master.sort_values("date").groupby(
        ["country", "indicator"], as_index=False
    ).tail(1).copy()

    x = x.rename(columns={
        "date": "latest_date",
        "value": "latest_value",
    })

    x.to_parquet(DATA / "latest_country_snapshot.parquet", index=False)
    return x

def run(event_rics: list[str] | None = None) -> None:
    cfg = load_series_config()

    history = fetch_datastream_history(cfg, years=3)
    master = build_features(history)
    latest_snapshot(master)

    if event_rics:
        fetch_economic_event_consensus(event_rics)

    print(f"Historical observations: {len(history):,}")
    print(f"Countries: {sorted(history['country'].unique().tolist()) if not history.empty else []}")
    print("Done.")

if __name__ == "__main__":
    run()
