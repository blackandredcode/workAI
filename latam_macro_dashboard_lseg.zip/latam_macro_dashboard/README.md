# LatAm Macro Dashboard — LSEG

## What this project does

This project creates a country-level macro monitor for:

- Brazil
- Mexico
- Colombia
- Chile
- Peru

The initial indicator set is:

- GDP
- CPI
- PPI
- Central-bank policy rate
- Unemployment
- Industrial production

It stores approximately three years of history and calculates:

- month-over-month change
- year-over-year change
- 3-month delta
- 12-month delta
- 36-month z-score

It also supports an LSEG Economic Monitor consensus layer.

## Important distinction about forecasts

LSEG economic-event consensus is not the same thing as a 1–3 year macro forecast.

The event layer provides fields such as actual, prior, revision and Reuters/LSEG survey consensus for upcoming economic releases.

For annual/quarterly forward forecasts, add the appropriate LSEG forecast/Datastream series to `config/series.csv` after locating the series in Workspace/Data Item Browser.

## Setup

### 1. Install

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Windows:

```powershell
.venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Credentials

Copy `.env.example` to `.env` and populate your Datastream credentials.

For Workspace/Desktop authentication, LSEG Data Library can use:

```python
import lseg.data as ld
ld.open_session()
```

with the Workspace application open.

### 3. Populate Datastream symbols

Open LSEG Workspace / Datastream Economics and identify the exact series symbols for each country/indicator.

Populate:

`config/series.csv`

The script intentionally does not hard-code guessed LatAm symbols because exact symbols, series definitions and entitlements can differ.

### 4. Run the historical pipeline

```bash
python macro_pipeline.py
```

Output:

```text
data/raw_history.parquet
data/macro_master.parquet
data/latest_country_snapshot.parquet
```

### 5. Launch dashboard

```bash
streamlit run dashboard.py
```

## Economic-event consensus

Use Workspace Economic Monitor to select the five countries and required indicators, then export the Economic Indicator RICs.

The pipeline function:

```python
fetch_economic_event_consensus(event_rics)
```

uses:

- ECI_ACT_DT
- FCAST_PRD
- ECON_ACT
- RTR_POLL
- ECON_PRIOR
- ECON_REV

These are useful for a release-surprise/consensus panel.

## Recommended next version

For a trading-oriented LatAm macro dashboard, add:

### Rates
- policy rate
- 2Y/5Y/10Y local yields
- real policy rate
- yield-curve slope
- FRA/OIS where available

### Inflation
- headline CPI
- core CPI
- PPI
- inflation expectations
- breakevens

### Growth
- GDP
- industrial production
- retail sales
- unemployment
- PMI
- consumer confidence

### Fiscal
- primary balance
- fiscal deficit
- public debt/GDP
- debt maturity
- government revenue/spending

### External
- current account
- trade balance
- reserves
- terms of trade
- commodity exposure

### FX / market
- spot
- 1M/3M/12M forwards
- NDF
- implied volatility
- CDS
- sovereign spreads
- local equity ETF
- USD/commodity beta

### Derived trading signals
- real rate
- monetary-policy surprise
- inflation surprise
- growth surprise
- macro momentum
- rate differential vs USD
- carry
- z-score
- regime/HMM state
- country relative-value scores

This structure is suitable for turning the dashboard into a LatAm FX/rates macro signal engine.
