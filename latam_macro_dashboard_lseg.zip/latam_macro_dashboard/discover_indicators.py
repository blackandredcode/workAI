"""
Discover LSEG economic-indicator RICs.

This is useful for building the event/consensus layer. LSEG's Economic
Monitor can export country-specific event RICs; this script provides a
programmatic search route as well.

Run after opening a Workspace/Desktop LSEG session.
"""

import pandas as pd
import lseg.data as ld

COUNTRIES = ["Brazil", "Mexico", "Colombia", "Chile", "Peru"]
KEYWORDS = ["GDP", "CPI", "PPI", "policy rate", "interest rate",
            "unemployment", "industrial production"]

def discover():
    ld.open_session()

    rows = []
    for country in COUNTRIES:
        for keyword in KEYWORDS:
            query = f"{country} {keyword}"
            try:
                # Free-text discovery is intentionally used here because
                # exact field availability varies by LSEG entitlement/content.
                df = ld.discovery.search(query)
                if df is None or df.empty:
                    continue

                df = df.copy()
                if "RIC" in df.columns:
                    df["country_query"] = country
                    df["keyword"] = keyword
                    rows.append(df)

            except Exception as exc:
                print(f"[WARN] {query}: {exc}")

    if rows:
        out = pd.concat(rows, ignore_index=True)
        out.to_csv("economic_indicator_candidates.csv", index=False)
        print("Wrote economic_indicator_candidates.csv")
    else:
        print("No candidates returned.")

if __name__ == "__main__":
    discover()
